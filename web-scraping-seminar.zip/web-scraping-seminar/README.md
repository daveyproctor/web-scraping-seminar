# Intro to web scraping in python 3

## uses bs4 (beautiful soup) and requests

## usage:
`$ git clone https://github.com/daveyproctor/web-scraping-seminar`

## Follow along from there!